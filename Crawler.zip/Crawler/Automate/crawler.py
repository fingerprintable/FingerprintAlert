import argparse
from urllib.parse import urlparse
import logging
import os
import time

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException

import coloredlogs

logger = logging.getLogger()
coloredlogs.install(level='DEBUG')


def crawl_websites(start, end):
    chrome_options = Options()
    prefs = {"download.default_directory": "/Users/nasser/Desktop/Crawling/crawldata/"}
    chrome_options.add_experimental_option("prefs", prefs)
    chrome_options.add_extension('/Users/nasser/Desktop/Crawling/FingerprintPost.crx')
    driver = webdriver.Chrome(chrome_options=chrome_options)
    # driver.set_page_load_timeout(60)
    timeout_list = []
    for i, line in enumerate(open("top_10000_websites.txt", "r")):
        url = line.strip()
        if i < start:
            continue
        if i > end:
            logger.debug("Stopped at {0} website".format(i))
            os.system(
                "say 'For hes a jolly good fellow for hes a jolly good fellow! For hes a jolly good fellow which nobody can deny! Which nobody can deny which nobody can deny! For hes a jolly good fellow for hes a jolly good fellow! For hes a jolly good fellow which nobody can deny! Congratulations you are done!'")
            getConsent = input("Done!")

            if getConsent.lower() == "go":
                stop = True
            elif getConsent.lower() == "no":
                stop = False
            if stop:
                driver.quit()
        try:
            driver.get(url)
        except TimeoutException as e:
            logger.debug(e)
            # has to do in this way cause the webdriver issues at
            # https://stackoverflow.com/questions/9876529/make-headless-browser-stop-loading-page
            timeout_list.append(url)
            with open("timeout_websites.txt", "a") as f:
                for website in timeout_list:
                    f.write(website + "\n")
            logger.debug("Stopped at {0} website".format(i))
            os.system(
                "say 'Its me the crawler! Please restart at {0}'".format(i))
            os.system("say 'you know what to do'")
            getConsent = input("Do you want to stop the crawler, Yes or no? ")
            if getConsent.lower() == "yes":
                stop = True
            elif getConsent.lower() == "no":
                stop = False
            if stop:
                driver.quit()
        finally:
			# wait for 10 seconds to start the next website         	
        	 time.sleep(3)


def crawl(url):
    chrome_options = Options()
    chrome_options.add_extension('/Users/nasser/Desktop/Crawling/FingerprintPost.crx')
    driver = webdriver.Chrome(chrome_options=chrome_options)
    driver.set_page_load_timeout(5)
    try:
        driver.get(url)
    except Exception as e:
        logger.debug(e)
        driver.set_script_timeout(3)
        driver.execute_script("window.stop();")
        try:
            driver.set_page_load_timeout(30)
            driver.post("http://google.com")
        except Exception as e:
            logger.debug(e)
        # driver.execute_script("window.stop()")
    else:
        driver.close()
        logger.debug("Process completes!")


def main():

    parser = argparse.ArgumentParser(usage="python3 auto.py -s <number of websites to start> -e <number of websites to end>",
                                     description='Extract main contents from a video file!!')
    parser.add_argument("-s", "--start", type=int, dest="start",
                        help="the n websites to start!")
    parser.add_argument("-e", "--end", type=int, dest="end",
                        help="the n websites to end!")
    args = parser.parse_args()
    s = args.start
    e = args.end
    crawl_websites(s, e)


if __name__ == '__main__':
    main()
