// create the report page
function checkResult(){
    chrome.tabs.create({url: chrome.extension.getURL("contents/report.html"), active:true}, function(tab){
        console.log("New tabs was crated!!!!");
    });
}
// create the report page
function buildMap(){
    chrome.tabs.create({url: chrome.extension.getURL("contents/report.html"), active:true}, function(tab){
        console.log("New tabs was crated!!!!");
    });
}


// create help page
function help(){
    chrome.tabs.create({url: chrome.extension.getURL("contents/help.html"), active:true}, function(tab){
        console.log("New tab was created!!!!");
    });
}
// export collected data
function exportData() {
    // body...
    var data = {};
    var urls = Object.keys(localStorage);
    for (var i = 0; i < urls.length; i++) {
        if (urls[i] === "status"){
            continue;
        }
        var value = localStorage.getItem(urls[i]);
        // preserve newlines, etc - use valid JSON
        // console.log(typeof(JSON.parse(value)));
        data[urls[i]] = JSON.parse(value);
    }
    chrome.downloads.download({
        url: "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data)),
        filename: "data.json",
        conflictAction: "uniquify", // or "overwrite" / "prompt"
        saveAs: false, // true gives save-as dialogue
    }, function(downloadId) {
        console.log("Downloaded item with ID", downloadId);
    });
}

function show(url) {
    options = {
        "iconUrl": '/images/green.png',
        "title": url,
        "type": "basic",
        // "contextMessage": "is using POST to send your data",
        "message": url
    };
    chrome.notifications.create(options, function(notificationId)
    {
        setTimeout(function() {
        chrome.notifications.clear(notificationId);
    }, 3000);});
}

function clear(){
    localStorage.clear();
	location.reload(); // to force reset of block counter <|>nas code 
   show("FingerprintAlert storage has been cleared!");

}
// document.getElementById("check-report").onclick = checkResult;

document.addEventListener('DOMContentLoaded', function () {


    chrome.browserAction.setIcon({path:"/images/green.png"});
    var button = document.getElementById("check-report").onclick=buildMap;
    document.getElementById("clear-data").onclick = clear;
    document.getElementById("help").onclick=help;

    // set panel css
    document.getElementById("FingerPrint-board").childNodes[0].style.color = "red";
    document.getElementById("FingerPrint-board").childNodes[0].onclick = function() {
        document.getElementById("FingerPrint-board").childNodes[0].style.color = "red";
        document.getElementById("FingerPrint-tools").childNodes[0].style.color = "#2b2b2b";
        document.getElementById("finger-board").style.display = "inline-block";
        document.getElementById("finger-tools").style.display = "none";
    };
    document.getElementById("FingerPrint-tools").childNodes[0].onclick = function() {
        document.getElementById("FingerPrint-board").childNodes[0].style.color = "#2b2b2b";
        document.getElementById("FingerPrint-tools").childNodes[0].style.color = "red";
        document.getElementById("finger-board").style.display = "none";
        document.getElementById("finger-tools").style.display = "inline-block";
    };
    // read setting from the local storage.
    document.getElementById("finger-block").innerHTML = localStorage.getItem("blockingCounter") || 0;
    var blockingSetting = localStorage.getItem("blocking");
    var notificationSetting = localStorage.getItem("notification");

    if (blockingSetting) {
        blockingSetting = parseInt(blockingSetting);
        if (blockingSetting) {
            document.getElementById("blocking-setting").checked = true;
        }else{
            document.getElementById("blocking-setting").checked = false;
        }

    }else{
        document.getElementById("blocking-setting").checked = false;
        localStorage.setItem("blocking", 0);
    }
    if (notificationSetting) {
        notificationSetting = parseInt(notificationSetting);
        if (notificationSetting) {
            document.getElementById("notification-setting").checked = true;
        }else{
            document.getElementById("notification-setting").checked = false;
        }

    }else{
        document.getElementById("notification-setting").checked = true;
        localStorage.setItem("notification", 1);
    }

    document.getElementById("blocking-setting").onclick = function () {
        if(document.getElementById("blocking-setting").checked){
            localStorage.setItem("blocking", 1);
        }else{
            localStorage.setItem("blocking", 0);
        }
        // body...
    };
    document.getElementById("notification-setting").onclick = function () {
        if(document.getElementById("notification-setting").checked){
            localStorage.setItem("notification", 1);
        }else{
            localStorage.setItem("notification", 0);
        }
        // body...
    };


});

