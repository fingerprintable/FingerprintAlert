// get the device information
var status;
var xhr = new XMLHttpRequest();
xhr.open("GET", "https://cdn3.optimizely.com/js/geo2.js", true);
xhr.onreadystatechange = function() {
  if (xhr.readyState == 4) {
      // WARNING! Might be evaluating an evil script!
      var resp = eval(xhr.responseText);
      // Or this if it's work
      // chrome.tabs.executeScript(tabs[0].id, {code: xhr.responseText});
      fingerprint.IP = window['optimizely'][0][1].ip;
      fingerprint.city = window['optimizely'][0][1].location.city;
      // console.log( window['optimizely'][0])
  }
}
xhr.send();


const fingerprint = new Object();
fingerprint.userAgent = navigator.userAgent;
fingerprint.screeWidth = screen.width;
fingerprint.screenHeight = screen.height;
fingerprint.resolution = fingerprint.screeWidth + "x" + fingerprint.screenHeight;
fingerprint.language = navigator.language;
// get geo location of the device
var latlon = "";
fingerprint.charSet =document.characterSet;

function showPosition(position) {
    var latlon = position.coords.latitude + "," + position.coords.longitude;
    fingerprint.geoloc = latlon;
    // console.log(latlon);
}
var pos = navigator.geolocation.getCurrentPosition(showPosition);


/**
 * JavaScript Client Detection
 * (C) viazenetti GmbH (Christian Ludwig)
 * this code is copied from https://stackoverflow.com/questions/9514179/how-to-find-the-operating-system-version-using-javascript
 */
(function (window) {
    {
        var unknown = '-';

        // screen
        var screenSize = '';
        if (screen.width) {
            width = (screen.width) ? screen.width : '';
            height = (screen.height) ? screen.height : '';
            screenSize += '' + width + " x " + height;
        }

        // browser
        var nVer = navigator.appVersion;
        var nAgt = navigator.userAgent;
        var browser = navigator.appName;
        var version = '' + parseFloat(navigator.appVersion);
        var majorVersion = parseInt(navigator.appVersion, 10);
        var nameOffset, verOffset, ix;

        // Opera
        if ((verOffset = nAgt.indexOf('Opera')) != -1) {
            browser = 'Opera';
            version = nAgt.substring(verOffset + 6);
            if ((verOffset = nAgt.indexOf('Version')) != -1) {
                version = nAgt.substring(verOffset + 8);
            }
        }
        // Opera Next
        if ((verOffset = nAgt.indexOf('OPR')) != -1) {
            browser = 'Opera';
            version = nAgt.substring(verOffset + 4);
        }
        // Edge
        else if ((verOffset = nAgt.indexOf('Edge')) != -1) {
            browser = 'Microsoft Edge';
            version = nAgt.substring(verOffset + 5);
        }
        // MSIE
        else if ((verOffset = nAgt.indexOf('MSIE')) != -1) {
            browser = 'Microsoft Internet Explorer';
            version = nAgt.substring(verOffset + 5);
        }
        // Chrome
        else if ((verOffset = nAgt.indexOf('Chrome')) != -1) {
            browser = 'Chrome';
            version = nAgt.substring(verOffset + 7);
        }
        // Safari
        else if ((verOffset = nAgt.indexOf('Safari')) != -1) {
            browser = 'Safari';
            version = nAgt.substring(verOffset + 7);
            if ((verOffset = nAgt.indexOf('Version')) != -1) {
                version = nAgt.substring(verOffset + 8);
            }
        }
        // Firefox
        else if ((verOffset = nAgt.indexOf('Firefox')) != -1) {
            browser = 'Firefox';
            version = nAgt.substring(verOffset + 8);
        }
        // MSIE 11+
        else if (nAgt.indexOf('Trident/') != -1) {
            browser = 'Microsoft Internet Explorer';
            version = nAgt.substring(nAgt.indexOf('rv:') + 3);
        }
        // Other browsers
        else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) < (verOffset = nAgt.lastIndexOf('/'))) {
            browser = nAgt.substring(nameOffset, verOffset);
            version = nAgt.substring(verOffset + 1);
            if (browser.toLowerCase() == browser.toUpperCase()) {
                browser = navigator.appName;
            }
        }
        // trim the version string
        if ((ix = version.indexOf(';')) != -1) version = version.substring(0, ix);
        if ((ix = version.indexOf(' ')) != -1) version = version.substring(0, ix);
        if ((ix = version.indexOf(')')) != -1) version = version.substring(0, ix);

        majorVersion = parseInt('' + version, 10);
        if (isNaN(majorVersion)) {
            version = '' + parseFloat(navigator.appVersion);
            majorVersion = parseInt(navigator.appVersion, 10);
        }

        // mobile version
        var mobile = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/.test(nVer);

        // cookie
        var cookieEnabled = (navigator.cookieEnabled) ? true : false;

        if (typeof navigator.cookieEnabled == 'undefined' && !cookieEnabled) {
            document.cookie = 'testcookie';
            cookieEnabled = (document.cookie.indexOf('testcookie') != -1) ? true : false;
        }

        // system
        var os = unknown;
        var clientStrings = [
            {s:'Windows 10', r:/(Windows 10.0|Windows NT 10.0)/},
            {s:'Windows 8.1', r:/(Windows 8.1|Windows NT 6.3)/},
            {s:'Windows 8', r:/(Windows 8|Windows NT 6.2)/},
            {s:'Windows 7', r:/(Windows 7|Windows NT 6.1)/},
            {s:'Windows Vista', r:/Windows NT 6.0/},
            {s:'Windows Server 2003', r:/Windows NT 5.2/},
            {s:'Windows XP', r:/(Windows NT 5.1|Windows XP)/},
            {s:'Windows 2000', r:/(Windows NT 5.0|Windows 2000)/},
            {s:'Windows ME', r:/(Win 9x 4.90|Windows ME)/},
            {s:'Windows 98', r:/(Windows 98|Win98)/},
            {s:'Windows 95', r:/(Windows 95|Win95|Windows_95)/},
            {s:'Windows NT 4.0', r:/(Windows NT 4.0|WinNT4.0|WinNT|Windows NT)/},
            {s:'Windows CE', r:/Windows CE/},
            {s:'Windows 3.11', r:/Win16/},
            {s:'Android', r:/Android/},
            {s:'Open BSD', r:/OpenBSD/},
            {s:'Sun OS', r:/SunOS/},
            {s:'Linux', r:/(Linux|X11)/},
            {s:'iOS', r:/(iPhone|iPad|iPod)/},
            {s:'Mac OS X', r:/Mac OS X/},
            {s:'Mac OS', r:/(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/},
            {s:'QNX', r:/QNX/},
            {s:'UNIX', r:/UNIX/},
            {s:'BeOS', r:/BeOS/},
            {s:'OS/2', r:/OS\/2/},
            {s:'Search Bot', r:/(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask Jeeves\/Teoma|ia_archiver)/}
        ];
        for (var id in clientStrings) {
            var cs = clientStrings[id];
            if (cs.r.test(nAgt)) {
                os = cs.s;
                break;
            }
        }

        var osVersion = unknown;

        if (/Windows/.test(os)) {
            osVersion = /Windows (.*)/.exec(os)[1];
            os = 'Windows';
        }

        switch (os) {
            case 'Mac OS X':
                osVersion = /Mac OS X (10[\.\_\d]+)/.exec(nAgt)[1];
                break;

            case 'Android':
                osVersion = /Android ([\.\_\d]+)/.exec(nAgt)[1];
                break;

            case 'iOS':
                osVersion = /OS (\d+)_(\d+)_?(\d+)?/.exec(nVer);
                osVersion = osVersion[1] + '.' + osVersion[2] + '.' + (osVersion[3] | 0);
                break;
        }

        // flash (you'll need to include swfobject)
        /* script src="//ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js" */
        var flashVersion = 'no check';
        if (typeof swfobject != 'undefined') {
            var fv = swfobject.getFlashPlayerVersion();
            if (fv.major > 0) {
                flashVersion = fv.major + '.' + fv.minor + ' r' + fv.release;
            }
            else  {
                flashVersion = unknown;
            }
        }
    }

    window.jscd = {
        screen: screenSize,
        browser: browser,
        browserVersion: version,
        browserMajorVersion: majorVersion,
        mobile: mobile,
        os: os,
        osVersion: osVersion,
        cookies: cookieEnabled,
        flashVersion: flashVersion
    };
}(this));

fingerprint.OS = jscd.os;
fingerprint.browserName = jscd.browser;
fingerprint.browserVersion = jscd.browserVersion;
fingerprint.OSVersion = jscd.osVersion.replace(/_/g, ".");
fingerprint.flashVersion = jscd.flashVersion;

// get webgl information
var canvas = document.createElement('canvas');
var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
fingerprint.GPU = gl.getParameter(gl.getExtension("WEBGL_debug_renderer_info").UNMASKED_RENDERER_WEBGL);
fingerprint.GPU_vendor = gl.getParameter(gl.getExtension("WEBGL_debug_renderer_info").UNMASKED_VENDOR_WEBGL);
fingerprint.webglRenderer = gl.getParameter(gl.RENDERER);
fingerprint.webglVendor = gl.getParameter(gl.VENDOR);
fingerprint.webglVersion = gl.getParameter(gl.VERSION);


// get plugins information
var installedPlugins = [];
for (var i = 0; i < navigator.plugins.length; i++) {
    installedPlugins.push(navigator.plugins[i].name);
}
fingerprint.installedPlugins = installedPlugins;


// initiate FingerprintAlert
var initBlockingCounter = localStorage.getItem("blockingCounter");
if (!initBlockingCounter) {
    localStorage.setItem("blockingCounter", 0);
}

var initBlocking = localStorage.getItem("blocking");
if (!initBlocking) {
    localStorage.setItem("blocking", 1);
}

var initNotification = localStorage.getItem("notification");

if(!initNotification){
   localStorage.setItem("notification", 0);
}

// get geo location from localstorage
// log all the device info.
//

function printDeviceInformation(argument) {
    // print the device information!
    //
    console.log("The Device information:")
    console.log("   Resolution: " + fingerprint.resolution);
    console.log("   OS: " + fingerprint.OS);
    console.log("   OS Version: " + fingerprint.OSVersion);
    // console.log("   Flash Version: " + flashVersion)
    console.log("   User-Agent: " + fingerprint.userAgent);
    console.log("   Browser Name: " + fingerprint.browserName);
    console.log("   Browser Version: " + fingerprint.browserVersion);
    console.log("   WEBGL Renderer: " + fingerprint.webglRenderer);
    console.log("   WEBGL Vendor: " + fingerprint.webglVendor);
    console.log("   WEBGL Version: " + fingerprint.webglVersion);
    console.log("   GPU: " + fingerprint.GPU);
    console.log("   GPU Vendor: " + fingerprint.GPU_vendor);
    console.log("   Installed Plugins: " + fingerprint.installedPlugins);
    console.log("   Language: " + fingerprint.language);
    console.log("   Location: " + fingerprint.geoloc);
    console.log("   City: " + fingerprint.city);
    console.log("   IP: " + fingerprint.IP);
    console.log("   Character Set: " + fingerprint.charSet);
}
// initializing the Extension, wait for 10s to detect the device information.
var future = setTimeout(printDeviceInformation, 5000);


// clearInterval(future);

// extract contents of every post message
chrome.webRequest.onBeforeRequest.addListener(
    function(details) {
        var requestId = details.requestId;
        if (details.method === "POST"){
            // console.log(details.type);
            // console.log(details)
            try{
                var requestBody = decodeURIComponent(String.fromCharCode.apply(null, new Uint8Array(details.requestBody.raw[0].bytes)));
                // console.log(data);
            }catch(err){
                // nothing here!
                try{
                    var requestBody = details.requestBody.formData;
                    var isForm = true;
                }catch(err){
                    console.log("RequestBody is empty!");
                }

                // console.log(requestBody);
            }
            if (!requestBody) {
                return;
            }else{
                // // notify the user, the website is sending information use Post.
                // var url = details.url;
                // var urlHost = new URL(url);
                // var host = urlHost.host;
                // var domain = extractDomain(host);
                // var website = JSON.parse(localStorage.getItem(domain));
                // if (website){
                //     try{
                //         var showPost = website[0].post;
                //         if (showPost){
                //             console.log("The page notification has been shown before.")
                //         }
                //     }catch(e){
                //         show(details.url);
                //         website.unshift({"post": true, "data": requestBody});
                //         console.log(website)
                //         localStorage.setItem(domain, JSON.stringify(website));
                //     }
                // }else{
                //     show(details.url);
                //     var msg = [{"post": true, "data": requestBody}];
                //     localStorage.setItem(domain,JSON.stringify(msg));
                // }
            }
            if (isForm){
                // first print the formData in the console
                // console.log("The Webpage is: " + details.url);

                var buildForm = "";
                for(key in requestBody) {
                    buildForm = key+ '='+ requestBody[key][0] + ";";

                }
                // console.log("The formData is: ");
                // console.log(buildForm);
                var msg = extractData(buildForm, details);
                if (msg) {
                    // set the icon to red.
                    chrome.browserAction.setIcon({path: "/images/red.png"});
                    // chrome.browserAction.setPopup({popup: "/contents/notification.html"});
                    chrome.webRequest.onBeforeSendHeaders.addListener(function(dets){
                        var blocking = false;
                        // console.log(dets);
                        var detReuqestId = dets.requestId;
                        if (dets.method === "POST"){
                            if (requestId === detReuqestId){
                                // console.log("This is a request for the POST rquest with requestId " + requestId);
                                var headers = dets.requestHeaders;
                                for (var i = 0; i < headers.length; i++) {
                                    if(headers[i].name === "Referer"){
                                        referer = headers[i].value;
                                    }
                                }
                                // store status to local storage;
                                var referURL = new URL(referer);
                                var referHost = referURL.host;
                                var referDomain = extractDomain(referHost);
                                storeStatus(referDomain);

                                // store data to local storage
                                var urlHost = new URL(details.url);
                                var host = urlHost.host;
                                var domain = extractDomain(host);
                                var data = buildForm;
                                storeDetectedWebsites(domain, msg, referer, dets.method, data);
                                console.log(referer);
                                // display notification to users
                                var notificationSetting = localStorage.getItem("notification");
                                if (notificationSetting) {
                                    notificationSetting = parseInt(notificationSetting);
                                    if (notificationSetting) {
                                        show(domain, referDomain);
                                    }
                                }else{
                                    localStorage.setItem("notification", 1);
                                    show(domain, referDomain);
                                }
                                if (msg){
                                    blocking = true;
                                    // if (domain === "youtube.com"){
                                    //     blocking = false;
                                    // }
                                }

                                // get blocking setting from localStorage
                                var blockingSetting = localStorage.getItem("blocking");
                                if (blockingSetting) {
                                    blockingSetting = parseInt(blockingSetting);
                                    if (blockingSetting) {
                                        blockingSetting = true;
                                    }else{
                                        blockingSetting = false;
                                    }
                                }else{
                                    localStorage.setItem("blocking", 0);
                                    blockingSetting = false;
                                }

                                if (blocking && blockingSetting) {
                                     var blockingCounter = localStorage.getItem("blockingCounter");
                                     if (blockingCounter) {
                                         blockingCounter = parseInt(blockingCounter);
                                         blockingCounter += 1;
                                         console.log("we blocked the above request!");
                                     }else{
                                         blockingCounter = 1;
                                         console.log("we blocked the above request!");
                                     }
                                     localStorage.setItem("blockingCounter", blockingCounter);
                                 }
                            }
                        }
                        return { cancel: blocking };
                    },
                    {urls: ["<all_urls>"]},
                    ["blocking", "requestHeaders"]);
                }else{
                    // do nothing if no attribute is detected
                }
            }else{
                // console.log("The Webpage is: " + details.url);
                // console.log("The raw data is: ")
                // console.log(requestBody);
                var msg = extractData(requestBody, details);
                if (msg) {
                    // set the icon to red.
                    chrome.browserAction.setIcon({path:"/images/red.png"});
                    // chrome.browserAction.setPopup({popup: "/contents/notification.html"});

                    chrome.webRequest.onBeforeSendHeaders.addListener(function(dets){
                        // console.log(dets);
                        var blocking = false;
                        var detReuqestId = dets.requestId;
                        var referer = "";
                        if (dets.method === "POST"){
                            if (requestId === detReuqestId){
                                // console.log("This is a request for the POST rquest with requestId " + requestId);
                                var headers = dets.requestHeaders;
                                for (var i = 0; i < headers.length; i++) {
                                    if(headers[i].name === "Referer"){
                                        referer = headers[i].value;
                                    }
                                }
                                var urlHost = new URL(details.url);
                                var host = urlHost.host;
                                var domain = extractDomain(host);
                                var data = requestBody;
                                // display notification to users

                                // store status to local storage;
                                var referURL = new URL(referer);
                                var referHost = referURL.host;
                                var referDomain = extractDomain(referHost);
                                // show notification
                                var notificationSetting = localStorage.getItem("notification");
                                if (notificationSetting) {
                                    notificationSetting = parseInt(notificationSetting);
                                    if (notificationSetting) {
                                        show(domain, referDomain);
                                    }
                                }else{
                                    localStorage.setItem("notification", 1);
                                    show(domain, referDomain);
                                }

                                storeStatus(referDomain);

                                // store data to local storage
                                storeDetectedWebsites(domain, msg, referer, dets.method, data);
                                console.log(referer);
                                if (msg){
                                    blocking = true;
                                    
                                }

                                // get blocking setting from localStorage
                                var blockingSetting = localStorage.getItem("blocking");
                                if (blockingSetting) {
                                    blockingSetting = parseInt(blockingSetting);
                                    if (blockingSetting) {
                                        blocking = true;
                                    }else{
                                        blocking = false;
                                    }
                                }else{
                                    localStorage.setItem("blocking", 0);
                                    blocking = false;
                                }

                                if (blocking) {
                                     var blockingCounter = localStorage.getItem("blockingCounter");
                                     if (blockingCounter) {
                                         blockingCounter = parseInt(blockingCounter);
                                         blockingCounter += 1;
                                         console.log("we blocked the above request!");
                                     }else{
                                         blockingCounter = 1;
                                         console.log("we blocked the above request!");
                                     }
                                     localStorage.setItem("blockingCounter", blockingCounter);
                                 }
                            }
                        }
                        return { cancel: blocking };
                    },
                    {urls: ["<all_urls>"]},
                    ["blocking", "requestHeaders"]);

                }else{
                    // do nothing if no attribute is detected
                    // chrome.browserAction.setIcon({path:"/images/green.png"});
                }
            }
       }
       // blocking the request if any device information is detected
    },
    {urls: ["<all_urls>"]},
    ["blocking", "requestBody"]
);


// extract information from messages (not include post)

chrome.webRequest.onBeforeSendHeaders.addListener(
    function(details){
        var blocking = false;
        if (details.method !== "POST") {
            var headers = details.requestHeaders;
            var referer = "";
            for (var i = 0; i < headers.length; i++) {
                if(headers[i].name === "Referer"){
                    referer = headers[i].value;
                }
            }
            var data = details.url;
            var urlHost = new URL(data);
            var host = urlHost.host;
            var domain = extractDomain(host);
            var msg = extractData(decodeURIComponent(data), details);
            if (msg){
                blocking = true;
                // if (domain === "youtube.com"){
                //     blocking = false;
                // }
                // set the icon to red.
                storeDetectedWebsites(domain, msg, referer, details.method, data);
                console.log(referer);
            }else{

            }
        }

        // get blocking setting from localStorage
        var blockingSetting = localStorage.getItem("blocking");
        if (blockingSetting) {
            blockingSetting = parseInt(blockingSetting);
            if (blockingSetting) {
                blockingSetting = true;
            }else{
                blockingSetting = false;
            }
        }else{
            localStorage.setItem("blocking", 0);
            blockingSetting = false;
        }

        // blocking the request if any device information is detected

        if (blocking && blockingSetting) {
            blocking = true;
            var blockingCounter = localStorage.getItem("blockingCounter");
            if (blockingCounter) {
                blockingCounter = parseInt(blockingCounter);
                blockingCounter += 1;
            }else{
                blockingCounter = 1;
            }
            localStorage.setItem("blockingCounter", blockingCounter);
        }else{
            blocking = false;
        }
        return { cancel: blocking };
    },
    {urls: ["<all_urls>"]},
    ["blocking", "requestHeaders"]
);

// set icon to green once the icon has been clicked.
chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.browserAction.setIcon({path:"/images/green.png"});
});

// search through the raw data(jsonData or form data) of the request body.
// return Message{msg:{"detected info"}, toURL:"info_sent_to_url"}
function extractData(data, details){
    var msg = {};
    if ((data.indexOf(fingerprint.OS) !== -1 || data.toLowerCase().indexOf("mac os") !== -1 || data.toLowerCase().indexOf("macos") !== -1)||
        (data.toLowerCase().indexOf(fingerprint.browserName.toLowerCase()) !== -1 && data.indexOf(fingerprint.browserVersion)!== -1)||
        (data.indexOf(fingerprint.userAgent) !== -1) ||
        (data.indexOf(fingerprint.resolution) !== -1) ||
        ((data.indexOf(fingerprint.screeWidth) !== -1) && (data.indexOf(fingerprint.screenHeight) !== -1))){

        if (data.indexOf(fingerprint.resolution) !== -1) {
            msg.Resolution = fingerprint.resolution;
        }else if ((data.indexOf(fingerprint.screeWidth) !== -1) && (data.indexOf(fingerprint.screenHeight) !== -1)){
            msg.Resolution = fingerprint.screeWidth + "x" + fingerprint.screenHeight
        }
        // detect whether user agent has been sent.
        if (data.indexOf(fingerprint.userAgent) !== -1){
            msg.User_Agent = fingerprint.userAgent;
        }else if (data.toLowerCase().indexOf(fingerprint.browserName.toLowerCase()) !==-1 && data.indexOf(fingerprint.browserVersion)!== -1){
            msg.Browser_Name = fingerprint.browserName;
            msg.Browser_Version = fingerprint.browserVersion;
        }
        // detect OS information
        if (data.indexOf(fingerprint.OS) !== -1 || data.toLowerCase().indexOf("macos") !== -1 || data.toLowerCase().indexOf("mac os") !== -1 ){
            // versions has been turned off cause windows 10 might get too many false positives.
            if(data.indexOf(fingerprint.OS) !== -1){
                msg.OS_Name = fingerprint.OS;
            }else{
                msg.OS_Name = "MacOS";
            }
            if (data.indexOf(fingerprint.OSVersion)!== -1) {
                msg.OS_Version = fingerprint.OSVersion;
            }
            // msg += "OS Version: " + OSVersion + "; ";
        }

        // detect system language
        if (data.toLowerCase().indexOf(fingerprint.language.toLowerCase()) !== -1){
            msg.Language = fingerprint.language;
        }
        // detect geolocation
        if (data.indexOf(fingerprint.geoloc.split(",")[0]) !== -1) {
            msg.GEO_Location = fingerprint.geoloc
        }else{
            // use tricky ways to detect geolocation.
            var latitudeIndex = data.toLowerCase().indexOf("latitude");
            var longitudeIndex = data.toLowerCase().indexOf("longitude");
            var lat = "";
            var long = ""
            if (latitudeIndex !== -1 && longitudeIndex !== -1){
                lat = data.substr(latitudeIndex+10, 4);
                long = data.substr(longitudeIndex+11, 5);
                msg.GEO_Location =  "(" + lat + "," + long + ")";
            }
        }
        // detect character set
        if (data.indexOf(fingerprint.charSet) !== -1){
            msg.Character_Set = fingerprint.charSet;
        }
        // detect GPU
        if (data.indexOf(fingerprint.GPU)!== -1) {
            msg.GPU = fingerprint.GPU;
        }
        if (data.indexOf(fingerprint.GPU_vendor)!== -1) {
            msg.GPU_Vendor = fingerprint.GPU_vendor;
        }
        // detect WEBGL
        if(data.indexOf(fingerprint.webglVendor) !== -1 && (data.indexOf(fingerprint.webglVersion) !== -1 || data.indexOf(fingerprint.webglVersion.replace(/\s/g, ""))!==-1)){
            msg.WEBGL_Vendor = fingerprint.webglVendor;
            msg.WEBGL_Version = fingerprint.webglVersion;
        }

        // detect plugins
        var detectedPlugins="";
        for (var i = 0; i < fingerprint.installedPlugins.length; i++) {
            if(data.indexOf(fingerprint.installedPlugins[i]) !== -1){
                detectedPlugins += fingerprint.installedPlugins[i] + "::";
            }else if(data.indexOf(fingerprint.installedPlugins[i].replace(/\s/g, ''))!== -1){
                detectedPlugins += fingerprint.installedPlugins[i] + "::";
            }
        }
        if (detectedPlugins){
            msg.Installed_Plugins = detectedPlugins;
        }
        // detect IP address
        if (data.indexOf(fingerprint.IP) !== -1 )
        {
            msg.IP = fingerprint.IP;
        }
        // detect City
        if (data.toUpperCase().indexOf(fingerprint.city) !== -1 )
        {
            msg.City = fingerprint.city;
        }
        // alert("Attention: The website :" + details.url + " is collecting your data, including " + msg);
        // store detected websites to local storage

        console.warn("The website :" + details.url + " is collecting your data, including " + displayMessage(msg));
        if (details.method === "POST"){
            console.log("The POST data : " + data);
        }else{
            console.dir("The GET data : " + data);
        }
        const message = {"msg":msg, "toURL":details.url}
        return message;
    }else{
        return null;
    }
}

function displayMessage(msg) {
    var keys = Object.keys(msg);
    var notification = ""
    for (var i = 0; i < keys.length; i++) {
        var attribute = keys[i];
        var value = msg[attribute];
        attribute = attribute.replace("_", " ");
        var combo = attribute + ": " + value + " ;";
        notification += combo;
    }
    return notification;
    // body...
}

function containResolution(str) {
    var re = new RegExp('[0-9]{3,4}x[0-9]{3,4}');
    return re.exec(str);
}

function storeStatus(domain){
    try{
        var status = localStorage.getItem("status");
    }catch(e){
        console.log(e);
    }
    if (status) {
        var storedDomains = JSON.parse(status);
        if (storedDomains.length < 5){
            storedDomains.push(domain);
            localStorage.setItem("status", JSON.stringify(storedDomains));
        }else{
            storedDomains.splice(0,1);
            storedDomains.push(domain);
            localStorage.setItem("status", JSON.stringify(storedDomains));
        }
    }else{
        var storedDomains = [domain];
        localStorage.setItem("status", JSON.stringify(storedDomains));
    }
}

function storeDetectedWebsites(domain, message, referer, method, data){
    try{
        var websites = localStorage.getItem(domain);

    }catch(e){
        console.log(e);
    }
    if (websites) {
        var storedWebsites = JSON.parse(websites);
        // store websites in a set;
        var msg = message;
        msg.referer = referer;
        msg.method = method;
        msg.data = data;
        storedWebsites.push(msg);
        localStorage.setItem(domain, JSON.stringify(storedWebsites));
    }else{
        var msg = message;
        msg.referer = referer;
        msg.method = method;
        msg.data = data;
        var websiteToStore = [msg];
        localStorage.setItem(domain, JSON.stringify(websiteToStore));
    }
}

function show(url, referer) {
    options = {
        "iconUrl": 'images/red.png',
        "title": "Fingerprinting Alert!",
        "type": "basic",
        "message": referer + " \n is sending fingerprintable information to \n" + url
    };
    chrome.notifications.create(options, function(notificationId)
    {
        setTimeout(function() {
        chrome.notifications.clear(notificationId);
    }, 2000);});
}


/*
 * Domain name extractor. Turns host names into domain names
 * Adapted from Chris Zarate's public domain genpass tool:
 *  http://labs.zarate.org/passwd/
 */

function extractDomain(host) {
    var s;  // the final result
    // Begin Chris Zarate's code
    var host=host.split('.');

    if(host[2]!=null) {
        s=host[host.length-2]+'.'+host[host.length-1];
        domains='ab.ca|ac.ac|ac.at|ac.be|ac.cn|ac.il|ac.in|ac.jp|ac.kr|ac.nz|ac.th|ac.uk|ac.za|adm.br|adv.br|agro.pl|ah.cn|aid.pl|alt.za|am.br|arq.br|art.br|arts.ro|asn.au|asso.fr|asso.mc|atm.pl|auto.pl|bbs.tr|bc.ca|bio.br|biz.pl|bj.cn|br.com|cn.com|cng.br|cnt.br|co.ac|co.at|co.il|co.in|co.jp|co.kr|co.nz|co.th|co.uk|co.za|com.au|com.br|com.cn|com.ec|com.fr|com.hk|com.mm|com.mx|com.pl|com.ro|com.ru|com.sg|com.tr|com.tw|cq.cn|cri.nz|de.com|ecn.br|edu.au|edu.cn|edu.hk|edu.mm|edu.mx|edu.pl|edu.tr|edu.za|eng.br|ernet.in|esp.br|etc.br|eti.br|eu.com|eu.lv|fin.ec|firm.ro|fm.br|fot.br|fst.br|g12.br|gb.com|gb.net|gd.cn|gen.nz|gmina.pl|go.jp|go.kr|go.th|gob.mx|gov.br|gov.cn|gov.ec|gov.il|gov.in|gov.mm|gov.mx|gov.sg|gov.tr|gov.za|govt.nz|gs.cn|gsm.pl|gv.ac|gv.at|gx.cn|gz.cn|hb.cn|he.cn|hi.cn|hk.cn|hl.cn|hn.cn|hu.com|idv.tw|ind.br|inf.br|info.pl|info.ro|iwi.nz|jl.cn|jor.br|jpn.com|js.cn|k12.il|k12.tr|lel.br|ln.cn|ltd.uk|mail.pl|maori.nz|mb.ca|me.uk|med.br|med.ec|media.pl|mi.th|miasta.pl|mil.br|mil.ec|mil.nz|mil.pl|mil.tr|mil.za|mo.cn|muni.il|nb.ca|ne.jp|ne.kr|net.au|net.br|net.cn|net.ec|net.hk|net.il|net.in|net.mm|net.mx|net.nz|net.pl|net.ru|net.sg|net.th|net.tr|net.tw|net.za|nf.ca|ngo.za|nm.cn|nm.kr|no.com|nom.br|nom.pl|nom.ro|nom.za|ns.ca|nt.ca|nt.ro|ntr.br|nx.cn|odo.br|on.ca|or.ac|or.at|or.jp|or.kr|or.th|org.au|org.br|org.cn|org.ec|org.hk|org.il|org.mm|org.mx|org.nz|org.pl|org.ro|org.ru|org.sg|org.tr|org.tw|org.uk|org.za|pc.pl|pe.ca|plc.uk|ppg.br|presse.fr|priv.pl|pro.br|psc.br|psi.br|qc.ca|qc.com|qh.cn|re.kr|realestate.pl|rec.br|rec.ro|rel.pl|res.in|ru.com|sa.com|sc.cn|school.nz|school.za|se.com|se.net|sh.cn|shop.pl|sk.ca|sklep.pl|slg.br|sn.cn|sos.pl|store.ro|targi.pl|tj.cn|tm.fr|tm.mc|tm.pl|tm.ro|tm.za|tmp.br|tourism.pl|travel.pl|tur.br|turystyka.pl|tv.br|tw.cn|uk.co|uk.com|uk.net|us.com|uy.com|vet.br|web.za|web.com|www.ro|xj.cn|xz.cn|yk.ca|yn.cn|za.com';
        domains=domains.split('|');
        for(var i=0;i<domains.length;i++) {
            if(s==domains[i]) {
                s=host[host.length-3]+'.'+s;
                break;
            }
        }
    }else{
        s=host.join('.');
    }
    // End Chris Zarate's code
    return s;
}

// chrome.management.getAll(function (result){
//     console.log(result);
// });
