function insertToTable(method,domain, referer, msg, toURL, data) {
    var table = document.getElementById(domain+"-table");
    var row1 = table.insertRow(-1);
    var cell0 = row1.insertCell(0);
    var cell1 = row1.insertCell(1);
    var cell2 = row1.insertCell(2);
    var cell3 = row1.insertCell(3)
    var cell4 = row1.insertCell(4);
    // Add some text to the new cells:
    cell0.innerHTML = method
    cell1.innerHTML = msg
    var refererURL = new URL(referer);
    var refererOrigin = refererURL.origin;
    cell2.innerHTML = refererOrigin;
    var sentURL = new URL(toURL);
    var sentOrigin = sentURL.origin;
    cell3.innerHTML = sentOrigin;
    cell4.innerHTML = data;
    // body...
}

function buildMap(){

    var domains = Object.keys(localStorage);
    for (var i = 0; i < domains.length; i++) {
        if (domains[i] === "status" || domains[i] === "blockingCounter" || domains[i] === "notificaiton" || domains[i] === "blocking"){
            console.log("This is the status item.")
            continue;
        }
        var ref = domains[i].referer;

        // create table and set the table header!

        // reads the data from local storage and write to the table
        var records = JSON.parse(localStorage.getItem(domains[i]));
        // console.log(records);
        for (var j = 0; j < records.length; j++) {
            var ref = records[j].referer;
            var toURL = records[j].toURL;
            var msg = records[j].msg;
            msg = displayMessage(msg);
            var method = records[j].method;
            var data = records[j].data;
            if (!ref){
                continue;
            }
            var refURL = new URL(ref)
            var host = refURL.host;
            var refererdomain = extractDomain(host);
            var h1 = document.getElementById(refererdomain);
            // create h1 for a referer.
            if (h1){
                console.log("H1 for website: " + refererdomain + " has been created!");
            }else{
                var h = document.createElement("H1");
                h.setAttribute("id", refererdomain);
                var a = document.createElement("a");
                a.setAttribute("href", "#"+refererdomain);
                h.appendChild(a);
                var t = document.createTextNode(refererdomain + " sent your fingerprintable data to the following website(s)");     // Create a text node
                h.appendChild(t);
                document.body.appendChild(h);
            }
            // create the table for a site.
            var tab = document.getElementById(refererdomain+"-table");
            if (tab){
                console.log("Table for website: " + refererdomain + " has been created!");
            }else{
                var table = document.createElement("TABLE");
                table.setAttribute("id", refererdomain+"-table");
                table.setAttribute("class", "container");
                //
                // var header =  table.createTHead();
                // var row = header.insertRow(0);
                // var cell0 = row.insertCell(0);
                // // var cell0.setAttribute("class" ,"method-data");
                // var cell1 = row.insertCell(1);
                // // var cell1.setAttribute("class" ,"privacy-data");
                // var cell2 = row.insertCell(2);
                // // var cell2.setAttribute("class" ,"referer-data");
                // var cell3 = row.insertCell(3);
                // // var cell3.setAttribute("class" ,"location-data");
                // var cell4 = row.insertCell(4);
                // var cell4.setAttribute("class" ,"raw-data");
                //
                //
                // create table header
                var th0 = document.createElement("TH");
                var th1 = document.createElement("TH");
                var th2 = document.createElement("TH");
                var th3 = document.createElement("TH");
                var th4 = document.createElement("TH");

                th0.setAttribute("class", "method-data");
                th1.setAttribute("class", "privacy-data");
                th2.setAttribute("class", "referer-data");
                th3.setAttribute("class", "location-data");
                th4.setAttribute("class", "raw-data");

                var text0 = document.createTextNode("HTTP");
                var text1 = document.createTextNode("Attrib.");
                var text2 = document.createTextNode("Sender");
                var text3 = document.createTextNode("Receiver");
                var text4 = document.createTextNode("Data");
                th0.appendChild(text0);
                th1.appendChild(text1);
                th2.appendChild(text2);
                th3.appendChild(text3);
                th4.appendChild(text4);

                table.appendChild(th0);
                table.appendChild(th1);
                table.appendChild(th2);
                table.appendChild(th3);
                table.appendChild(th4);


                // cell0.innerHTML = "Method Used";
                // cell1.innerHTML = "Privacy Related Data";
                // cell2.innerHTML = "Referer";
                // cell3.innerHTML = "Sent to";
                // cell4.innerHTML = "Data";

                document.body.appendChild(table);
            }
            insertToTable(method,refererdomain, ref, msg, toURL, data);
        }
    }
}

buildMap();


function displayMessage(msg) {
    var keys = Object.keys(msg);
    var notification = ""
    for (var i = 0; i < keys.length; i++) {
        var attribute = keys[i];
        var value = msg[attribute];
        attribute = attribute.replace("_", " ");
        var combo = "<div style='width: 200px;'>"+ attribute + ": " + value + " </div>";
        notification += combo;
    }
    return notification;
    // body...
}
/*
 * Domain name extractor. Turns host names into domain names
 * Adapted from Chris Zarate's public domain genpass tool:
 *  http://labs.zarate.org/passwd/
 */

function extractDomain(host) {
    var s;  // the final result
    // Begin Chris Zarate's code
    var host=host.split('.');

    if(host[2]!=null) {
        s=host[host.length-2]+'.'+host[host.length-1];
        domains='ab.ca|ac.ac|ac.at|ac.be|ac.cn|ac.il|ac.in|ac.jp|ac.kr|ac.nz|ac.th|ac.uk|ac.za|adm.br|adv.br|agro.pl|ah.cn|aid.pl|alt.za|am.br|arq.br|art.br|arts.ro|asn.au|asso.fr|asso.mc|atm.pl|auto.pl|bbs.tr|bc.ca|bio.br|biz.pl|bj.cn|br.com|cn.com|cng.br|cnt.br|co.ac|co.at|co.il|co.in|co.jp|co.kr|co.nz|co.th|co.uk|co.za|com.au|com.br|com.cn|com.ec|com.fr|com.hk|com.mm|com.mx|com.pl|com.ro|com.ru|com.sg|com.tr|com.tw|cq.cn|cri.nz|de.com|ecn.br|edu.au|edu.cn|edu.hk|edu.mm|edu.mx|edu.pl|edu.tr|edu.za|eng.br|ernet.in|esp.br|etc.br|eti.br|eu.com|eu.lv|fin.ec|firm.ro|fm.br|fot.br|fst.br|g12.br|gb.com|gb.net|gd.cn|gen.nz|gmina.pl|go.jp|go.kr|go.th|gob.mx|gov.br|gov.cn|gov.ec|gov.il|gov.in|gov.mm|gov.mx|gov.sg|gov.tr|gov.za|govt.nz|gs.cn|gsm.pl|gv.ac|gv.at|gx.cn|gz.cn|hb.cn|he.cn|hi.cn|hk.cn|hl.cn|hn.cn|hu.com|idv.tw|ind.br|inf.br|info.pl|info.ro|iwi.nz|jl.cn|jor.br|jpn.com|js.cn|k12.il|k12.tr|lel.br|ln.cn|ltd.uk|mail.pl|maori.nz|mb.ca|me.uk|med.br|med.ec|media.pl|mi.th|miasta.pl|mil.br|mil.ec|mil.nz|mil.pl|mil.tr|mil.za|mo.cn|muni.il|nb.ca|ne.jp|ne.kr|net.au|net.br|net.cn|net.ec|net.hk|net.il|net.in|net.mm|net.mx|net.nz|net.pl|net.ru|net.sg|net.th|net.tr|net.tw|net.za|nf.ca|ngo.za|nm.cn|nm.kr|no.com|nom.br|nom.pl|nom.ro|nom.za|ns.ca|nt.ca|nt.ro|ntr.br|nx.cn|odo.br|on.ca|or.ac|or.at|or.jp|or.kr|or.th|org.au|org.br|org.cn|org.ec|org.hk|org.il|org.mm|org.mx|org.nz|org.pl|org.ro|org.ru|org.sg|org.tr|org.tw|org.uk|org.za|pc.pl|pe.ca|plc.uk|ppg.br|presse.fr|priv.pl|pro.br|psc.br|psi.br|qc.ca|qc.com|qh.cn|re.kr|realestate.pl|rec.br|rec.ro|rel.pl|res.in|ru.com|sa.com|sc.cn|school.nz|school.za|se.com|se.net|sh.cn|shop.pl|sk.ca|sklep.pl|slg.br|sn.cn|sos.pl|store.ro|targi.pl|tj.cn|tm.fr|tm.mc|tm.pl|tm.ro|tm.za|tmp.br|tourism.pl|travel.pl|tur.br|turystyka.pl|tv.br|tw.cn|uk.co|uk.com|uk.net|us.com|uy.com|vet.br|web.za|web.com|www.ro|xj.cn|xz.cn|yk.ca|yn.cn|za.com';
        domains=domains.split('|');
        for(var i=0;i<domains.length;i++) {
            if(s==domains[i]) {
                s=host[host.length-3]+'.'+s;
                break;
            }
        }
    }else{
        s=host.join('.');
    }
    // End Chris Zarate's code
    return s;
}
